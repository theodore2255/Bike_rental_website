package com.shounoop.bikerentalspring.enums;

public enum UserRole {
    ADMIN,
    CUSTOMER
}
