package com.shounoop.bikerentalspring.enums;

public enum BookBikeStatus {
    PENDING, APPROVED, REJECTED
}
