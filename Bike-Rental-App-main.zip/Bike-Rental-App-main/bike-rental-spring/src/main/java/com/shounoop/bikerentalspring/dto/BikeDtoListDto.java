package com.shounoop.bikerentalspring.dto;

import lombok.Data;

import java.util.List;

@Data
public class BikeDtoListDto {
    private List<BikeDto> bikeDtoList;
}
