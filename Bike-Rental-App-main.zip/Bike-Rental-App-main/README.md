## Bike Rental Project (Fullstack) with Spring Boot, Angular and MySQL
